package com.example.amperefinder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmpereFinderScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmpereFinderScreen() {
    var phase by remember { mutableStateOf("3 Phase") }
    var connection by remember { mutableStateOf("Star (Y)") }
    var powerType by remember { mutableStateOf("kW") }
    var voltage by remember { mutableStateOf("415") }
    var load by remember { mutableStateOf("15") }
    var pf by remember { mutableStateOf("0.85") }

    val v = voltage.toDoubleOrNull()
    val p = load.toDoubleOrNull()
    val powerFactor = pf.toDoubleOrNull()
    val valid = v != null && p != null && v > 0 && p > 0 &&
        (powerType == "kVA" || (powerFactor != null && powerFactor > 0 && powerFactor <= 1))

    var lineCurrent: Double? = null
    var phaseCurrent: Double? = null
    var phaseVoltage: Double? = null

    if (valid) {
        val totalVA = if (powerType == "kW") p!! * 1000.0 / powerFactor!! else p!! * 1000.0
        if (phase == "1 Phase") {
            lineCurrent = totalVA / v!!
            phaseCurrent = lineCurrent
            phaseVoltage = v
        } else {
            lineCurrent = totalVA / (sqrt(3.0) * v!!)
            if (connection == "Star (Y)") {
                phaseCurrent = lineCurrent
                phaseVoltage = v / sqrt(3.0)
            } else {
                phaseCurrent = lineCurrent / sqrt(3.0)
                phaseVoltage = v
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF087F5B),
            secondary = Color(0xFF176B87),
            background = Color(0xFFF5F7F8)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("AMPERE FINDER", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF087F5B))
                    Text("Electrical Current Calculator", color = Color.DarkGray, fontSize = 13.sp)
                }

                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PHASE", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ChoiceChip("1 Phase", phase == "1 Phase") { phase = "1 Phase" }
                            ChoiceChip("3 Phase", phase == "3 Phase") { phase = "3 Phase" }
                        }

                        if (phase == "3 Phase") {
                            Text("CONNECTION", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ChoiceChip("Star (Y)", connection == "Star (Y)") { connection = "Star (Y)" }
                                ChoiceChip("Delta (Δ)", connection == "Delta (Δ)") { connection = "Delta (Δ)" }
                            }
                        }

                        Text("LOAD TYPE", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ChoiceChip("kW", powerType == "kW") { powerType = "kW" }
                            ChoiceChip("kVA", powerType == "kVA") { powerType = "kVA" }
                        }

                        OutlinedTextField(
                            value = voltage, onValueChange = { voltage = it },
                            label = { Text(if (phase == "3 Phase") "Line Voltage (V)" else "Voltage (V)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = load, onValueChange = { load = it },
                            label = { Text("Load (${powerType})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        if (powerType == "kW") {
                            OutlinedTextField(
                                value = pf, onValueChange = { pf = it },
                                label = { Text("Power Factor (0 to 1)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true, modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Text(
                            if (phase == "3 Phase") "Enter line-to-line voltage (e.g. 415 V)." else "Enter the voltage across the single-phase load.",
                            fontSize = 12.sp, color = Color.Gray
                        )
                    }
                }

                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F5EF))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CALCULATION RESULT", fontWeight = FontWeight.Bold, color = Color(0xFF087F5B))
                        if (valid && lineCurrent != null && phaseCurrent != null) {
                            ResultRow("Line Current", lineCurrent!!)
                            ResultRow("Phase Current", phaseCurrent!!)
                            ResultRow("Phase Voltage", phaseVoltage!!)
                        } else {
                            Text("Enter valid positive values to calculate.", color = Color.DarkGray)
                            if (powerType == "kW") Text("Power factor must be greater than 0 and up to 1.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                Text(
                    "Formula assumes a balanced sinusoidal load. For kW, power factor is required. Actual motor current can differ due to efficiency, harmonics and operating conditions.",
                    fontSize = 11.sp, color = Color.Gray
                )
                Text("Ampere Finder • Version 1.0", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@Composable
fun ResultRow(label: String, value: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = FontWeight.Medium)
        Text(String.format("%.2f A", value), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF087F5B))
    }
}
