AMPERE FINDER - Android Studio project

Features:
- 1-phase and 3-phase selection
- Star (Y) and Delta connection selection for 3-phase
- kW and kVA selectable load input
- Power factor input for kW
- Line current, phase current and phase voltage results

Electrical assumptions:
- Single phase: entered voltage is load voltage; line current equals phase current.
- Three phase: entered voltage is line-to-line voltage.
- Balanced three-phase load.
- kW calculations use PF; kVA calculations do not require PF.
- Star: Iline = Iphase; Vphase = Vline / sqrt(3).
- Delta: Iline = sqrt(3) * Iphase; Vphase = Vline.

To build:
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

Note: This source project has not been compiled in this environment. Please build and test it in Android Studio before field use.
